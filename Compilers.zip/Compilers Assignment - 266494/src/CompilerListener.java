// Generated from java-escape by ANTLR 4.11.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link CompilerParser}.
 */
public interface CompilerListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link CompilerParser#prog}.
	 * @param ctx the parse tree
	 */
	void enterProg(CompilerParser.ProgContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilerParser#prog}.
	 * @param ctx the parse tree
	 */
	void exitProg(CompilerParser.ProgContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilerParser#dec}.
	 * @param ctx the parse tree
	 */
	void enterDec(CompilerParser.DecContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilerParser#dec}.
	 * @param ctx the parse tree
	 */
	void exitDec(CompilerParser.DecContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilerParser#vardec}.
	 * @param ctx the parse tree
	 */
	void enterVardec(CompilerParser.VardecContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilerParser#vardec}.
	 * @param ctx the parse tree
	 */
	void exitVardec(CompilerParser.VardecContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilerParser#body}.
	 * @param ctx the parse tree
	 */
	void enterBody(CompilerParser.BodyContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilerParser#body}.
	 * @param ctx the parse tree
	 */
	void exitBody(CompilerParser.BodyContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilerParser#block}.
	 * @param ctx the parse tree
	 */
	void enterBlock(CompilerParser.BlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilerParser#block}.
	 * @param ctx the parse tree
	 */
	void exitBlock(CompilerParser.BlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilerParser#ene}.
	 * @param ctx the parse tree
	 */
	void enterEne(CompilerParser.EneContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilerParser#ene}.
	 * @param ctx the parse tree
	 */
	void exitEne(CompilerParser.EneContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Identifier}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterIdentifier(CompilerParser.IdentifierContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Identifier}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitIdentifier(CompilerParser.IdentifierContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Int}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterInt(CompilerParser.IntContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Int}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitInt(CompilerParser.IntContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Boolean}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBoolean(CompilerParser.BooleanContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Boolean}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBoolean(CompilerParser.BooleanContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Assign}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterAssign(CompilerParser.AssignContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Assign}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitAssign(CompilerParser.AssignContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CompareExp}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterCompareExp(CompilerParser.CompareExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CompareExp}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitCompareExp(CompilerParser.CompareExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ArithmeticExp}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterArithmeticExp(CompilerParser.ArithmeticExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ArithmeticExp}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitArithmeticExp(CompilerParser.ArithmeticExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code LogicExp}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterLogicExp(CompilerParser.LogicExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code LogicExp}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitLogicExp(CompilerParser.LogicExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IdentifierArgs}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterIdentifierArgs(CompilerParser.IdentifierArgsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IdentifierArgs}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitIdentifierArgs(CompilerParser.IdentifierArgsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BlockExp}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBlockExp(CompilerParser.BlockExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BlockExp}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBlockExp(CompilerParser.BlockExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IfThen}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterIfThen(CompilerParser.IfThenContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IfThen}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitIfThen(CompilerParser.IfThenContext ctx);
	/**
	 * Enter a parse tree produced by the {@code DoWhile}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterDoWhile(CompilerParser.DoWhileContext ctx);
	/**
	 * Exit a parse tree produced by the {@code DoWhile}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitDoWhile(CompilerParser.DoWhileContext ctx);
	/**
	 * Enter a parse tree produced by the {@code RepeatUntil}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterRepeatUntil(CompilerParser.RepeatUntilContext ctx);
	/**
	 * Exit a parse tree produced by the {@code RepeatUntil}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitRepeatUntil(CompilerParser.RepeatUntilContext ctx);
	/**
	 * Enter a parse tree produced by the {@code PrintExp}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterPrintExp(CompilerParser.PrintExpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code PrintExp}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitPrintExp(CompilerParser.PrintExpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Space}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterSpace(CompilerParser.SpaceContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Space}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitSpace(CompilerParser.SpaceContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NewLine}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterNewLine(CompilerParser.NewLineContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NewLine}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitNewLine(CompilerParser.NewLineContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Skip}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterSkip(CompilerParser.SkipContext ctx);
	/**
	 * Exit a parse tree produced by the {@code Skip}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitSkip(CompilerParser.SkipContext ctx);
	/**
	 * Enter a parse tree produced by {@link CompilerParser#args}.
	 * @param ctx the parse tree
	 */
	void enterArgs(CompilerParser.ArgsContext ctx);
	/**
	 * Exit a parse tree produced by {@link CompilerParser#args}.
	 * @param ctx the parse tree
	 */
	void exitArgs(CompilerParser.ArgsContext ctx);
}