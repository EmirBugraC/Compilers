// Generated from java-escape by ANTLR 4.11.1
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link CompilerParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface CompilerVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link CompilerParser#prog}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProg(CompilerParser.ProgContext ctx);
	/**
	 * Visit a parse tree produced by {@link CompilerParser#dec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDec(CompilerParser.DecContext ctx);
	/**
	 * Visit a parse tree produced by {@link CompilerParser#vardec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVardec(CompilerParser.VardecContext ctx);
	/**
	 * Visit a parse tree produced by {@link CompilerParser#body}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBody(CompilerParser.BodyContext ctx);
	/**
	 * Visit a parse tree produced by {@link CompilerParser#block}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlock(CompilerParser.BlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link CompilerParser#ene}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEne(CompilerParser.EneContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Identifier}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentifier(CompilerParser.IdentifierContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Int}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInt(CompilerParser.IntContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Boolean}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolean(CompilerParser.BooleanContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Assign}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssign(CompilerParser.AssignContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CompareExp}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompareExp(CompilerParser.CompareExpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ArithmeticExp}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArithmeticExp(CompilerParser.ArithmeticExpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code LogicExp}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogicExp(CompilerParser.LogicExpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code IdentifierArgs}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentifierArgs(CompilerParser.IdentifierArgsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BlockExp}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockExp(CompilerParser.BlockExpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code IfThen}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfThen(CompilerParser.IfThenContext ctx);
	/**
	 * Visit a parse tree produced by the {@code DoWhile}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDoWhile(CompilerParser.DoWhileContext ctx);
	/**
	 * Visit a parse tree produced by the {@code RepeatUntil}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRepeatUntil(CompilerParser.RepeatUntilContext ctx);
	/**
	 * Visit a parse tree produced by the {@code PrintExp}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrintExp(CompilerParser.PrintExpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Space}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSpace(CompilerParser.SpaceContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NewLine}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNewLine(CompilerParser.NewLineContext ctx);
	/**
	 * Visit a parse tree produced by the {@code Skip}
	 * labeled alternative in {@link CompilerParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSkip(CompilerParser.SkipContext ctx);
	/**
	 * Visit a parse tree produced by {@link CompilerParser#args}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArgs(CompilerParser.ArgsContext ctx);
}