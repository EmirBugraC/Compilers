import org.antlr.v4.runtime.*;
import org.stringtemplate.v4.compiler.Compiler;

public class Task1 {

    public static void main(String[] args) throws Exception {

        CharStream input = CharStreams.fromStream(System.in);

        CompilerLexer lexer = new CompilerLexer(input);

        CommonTokenStream tokens = new CommonTokenStream(lexer);

        CompilerParser parser = new CompilerParser(tokens);
        CompilerParser.ProgContext tree = parser.prog();

        TypeChecker checker = new TypeChecker();
        try {
            checker.visit(tree);
        } catch (TypeException ex) {
            System.out.println(ex.report());
            return;
        }

        /*CompilerInterpreter interpreter = new CompilerInterpreter();
        Integer mainReturnValue = interpreter.visitProgram(tree, args);
        System.out.println();
        System.out.println("NORMAL_TERMINATION");
        System.out.println(mainReturnValue);*/

    }
}