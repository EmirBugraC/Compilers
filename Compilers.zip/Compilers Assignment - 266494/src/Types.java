public enum Types {
    INT, BOOL, UNIT
}
