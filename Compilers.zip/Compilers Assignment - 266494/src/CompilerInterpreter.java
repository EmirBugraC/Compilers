import org.antlr.v4.runtime.tree.AbstractParseTreeVisitor;

import java.util.HashMap;
import java.util.Map;

public class CompilerInterpreter extends AbstractParseTreeVisitor<Integer> implements CompilerVisitor<Integer> {

    private final Map<String, Integer> localVars = new HashMap<>();
    @Override public Integer visitProg(CompilerParser.ProgContext ctx) { return visitChildren(ctx); }

    @Override public Integer visitDec(CompilerParser.DecContext ctx) { return visitChildren(ctx); }

    @Override public Integer visitVardec(CompilerParser.VardecContext ctx) { return visitChildren(ctx); }

    @Override public Integer visitBody(CompilerParser.BodyContext ctx) { return visitChildren(ctx); }

    @Override public Integer visitBlock(CompilerParser.BlockContext ctx) { return visitChildren(ctx); }

    @Override public Integer visitEne(CompilerParser.EneContext ctx) {
        for (int i = 0; i < ctx.expr().size(); ++i) {
            visit(ctx.expr().get(i));
        }
        return null;
    }

    @Override public Integer visitIdentifier(CompilerParser.IdentifierContext ctx) {
        return localVars.get(ctx.IDFR().getText()); }

    @Override public Integer visitInt(CompilerParser.IntContext ctx) {
        return Integer.parseInt(ctx.INTLIT().getText()); }

    @Override public Integer visitBoolean(CompilerParser.BooleanContext ctx) {
        return Integer.parseInt(ctx.BOOLLIT().getText()); }

    @Override public Integer visitAssign(CompilerParser.AssignContext ctx) {
        localVars.replace(ctx.IDFR().getText(), visit(ctx.expr()));
        return null;
    }

    @Override public Integer visitCompareExp(CompilerParser.CompareExpContext ctx) { return visitChildren(ctx); }

    @Override public Integer visitArithmeticExp(CompilerParser.ArithmeticExpContext ctx) { return visitChildren(ctx); }

    @Override public Integer visitLogicExp(CompilerParser.LogicExpContext ctx) { return visitChildren(ctx); }

    @Override public Integer visitIdentifierArgs(CompilerParser.IdentifierArgsContext ctx) { return visitChildren(ctx); }

    @Override public Integer visitBlockExp(CompilerParser.BlockExpContext ctx) { return visitChildren(ctx); }

    @Override public Integer visitIfThen(CompilerParser.IfThenContext ctx) { return visitChildren(ctx); }

    @Override public Integer visitDoWhile(CompilerParser.DoWhileContext ctx) {
        while (visit(ctx.expr()) > 0) {
            visit(ctx.block());
        }
        return null;
    }

    @Override public Integer visitRepeatUntil(CompilerParser.RepeatUntilContext ctx) {
        while (visit(ctx.block()) > 0) {
            visit(ctx.expr());
        }
        return null;
    }

    @Override public Integer visitPrintExp(CompilerParser.PrintExpContext ctx) { return visitChildren(ctx); }

    @Override public Integer visitSpace(CompilerParser.SpaceContext ctx) { return null; }

    @Override public Integer visitNewLine(CompilerParser.NewLineContext ctx) { return null; }

    @Override public Integer visitSkip(CompilerParser.SkipContext ctx) { return null; }

    @Override public Integer visitArgs(CompilerParser.ArgsContext ctx) { return visitChildren(ctx); }
}

