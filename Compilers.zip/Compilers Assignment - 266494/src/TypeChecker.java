// Generated from /Users/emirbugracakmak/Library/Mobile Documents/com~apple~CloudDocs/Compilers Assignment - 266494/src/Compiler.g4 by ANTLR 4.10.1
import org.antlr.v4.runtime.tree.AbstractParseTreeVisitor;
import java.util.HashMap;
import java.util.Map;

public class TypeChecker extends AbstractParseTreeVisitor<Types> implements CompilerVisitor<Types> {

    private final Map<String, Types> localVars = new HashMap<>();
    private final Map<String, Types> funcNames = new HashMap<>();
    private final Map<String, Integer> funcArgNum = new HashMap<>();
    @Override public Types visitProg(CompilerParser.ProgContext ctx) { //must be added
        for (int i = 0; i < ctx.dec().size(); ++i) {
            if (!ctx.dec(i).IDFR().getText().equals("main")) {
                throw new TypeException().noMainFuncError();
            }if(visit(ctx.dec(i).TYPE()) != Types.INT ){
                throw new TypeException().mainReturnTypeError();
            }
        }
        return Types.INT;
    }

    @Override public Types visitDec(CompilerParser.DecContext ctx) { //must be added
        for (int i = 0; i < ctx.vardec().IDFR().size(); ++i) {
            if (funcNames.containsKey(ctx.vardec().IDFR(i).getText())) {
                throw new TypeException().duplicatedFuncError();
            }
            funcNames.put(ctx.vardec().IDFR(i).getText(), Types.INT);
            funcArgNum.put(ctx.vardec().IDFR(i).getText(), ctx.vardec().IDFR().size());
        }
        Types returnType = null;
        for (int i = 0; i < ctx.body().expr().size(); ++i) {
            CompilerParser.ExprContext lastexpr = ctx.body().expr().get(i);
            returnType = visit(lastexpr);
        }
        return returnType;
    }

    @Override public Types visitVardec(CompilerParser.VardecContext ctx) { //must be added
        for (int i = 0; i < ctx.TYPE().size(); ++i) {
            if (visit(ctx.TYPE(i)) == Types.UNIT){
                throw new TypeException().unitVarError();
            }
        }
        for (int i = 0; i < ctx.IDFR().size(); ++i) {
            if (localVars.containsKey(ctx.IDFR(i).getText())) {
                throw new TypeException().duplicatedVarError();
            }
            if (funcNames.containsKey(ctx.IDFR(i).getText())) {
                throw new TypeException().clashedVarError();
            }
            localVars.put(ctx.IDFR(i).getText(), Types.INT);
        }
        return visitChildren(ctx);
    }

    @Override public Types visitBody(CompilerParser.BodyContext ctx) { //must be added
        for (int i = 0; i < ctx.expr().size(); ++i) {
            if (visit(ctx.TYPE(i)) != visit(ctx.expr(i))){
                throw new TypeException().functionBodyError();
            }
        }
        return visitChildren(ctx);
    }

    @Override public Types visitBlock(CompilerParser.BlockContext ctx) { //correct
        return visit(ctx.ene());
    }

    @Override public Types visitEne(CompilerParser.EneContext ctx) { //correct
        Types returnType = null;
        for (int i = 0; i < ctx.expr().size(); ++i) {
            CompilerParser.ExprContext lastexpr = ctx.expr().get(i);
            returnType = visit(lastexpr);
        }
        return returnType;
    }

    @Override public Types visitIdentifier(CompilerParser.IdentifierContext ctx) { //must be added
        if (!localVars.containsKey(ctx.IDFR().getText())) {
            throw new TypeException().undefinedVarError();
        }
        return Types.INT;
    }

    @Override public Types visitInt(CompilerParser.IntContext ctx) { //correct
        return Types.INT;
    }

    @Override public Types visitBoolean(CompilerParser.BooleanContext ctx) {//correct
        return Types.BOOL;
    }

    @Override public Types visitAssign(CompilerParser.AssignContext ctx) {//must be added
        if (!localVars.containsKey(ctx.IDFR().getText())) {
            throw new TypeException().undefinedVarError();
        }
        if (visit(ctx.IDFR()) != visit(ctx.expr())) {
            throw new TypeException().assignmentError();
        }
        return Types.UNIT;
    }

    @Override public Types visitCompareExp(CompilerParser.CompareExpContext ctx) { //correct
        if (visit(ctx.expr(0)) == Types.BOOL && visit(ctx.expr(1)) == Types.BOOL) {
            return Types.BOOL;
        } else {
            throw new TypeException().comparisonError();
        }
    }

    @Override public Types visitArithmeticExp(CompilerParser.ArithmeticExpContext ctx) {//correct
        if (visit(ctx.expr(0)) == Types.INT && visit(ctx.expr(1)) == Types.INT) {
            return Types.INT;
        } else {
            throw new TypeException().arithmeticError();
        }
    }

    @Override public Types visitLogicExp(CompilerParser.LogicExpContext ctx) { //correct
        if (visit(ctx.expr(0)) == Types.BOOL && visit(ctx.expr(1)) == Types.BOOL) {
            return Types.BOOL;
        } else {
            throw new TypeException().logicalError();
        }
    }


    @Override public Types visitIdentifierArgs(CompilerParser.IdentifierArgsContext ctx) { //must be added
        if (!funcArgNum.containsKey(ctx.IDFR().getText())) {
            throw new TypeException().undefinedFuncError();
        }
        if(ctx.args().expr().size() != funcArgNum.get(ctx.IDFR().getText())){
            throw new TypeException().argumentNumberError();
        }
        return visit(ctx.args());
    }

    @Override public Types visitBlockExp(CompilerParser.BlockExpContext ctx) { //correct
        return visit(ctx.block().ene());
    }

    @Override public Types visitIfThen(CompilerParser.IfThenContext ctx) { //correct
        if (visit(ctx.expr()) != Types.BOOL) {
            throw new TypeException().conditionError();
        }
        if (visit(ctx.block(0)) != visit(ctx.block(1))){
            throw new TypeException().branchMismatchError();
        }
        return Types.UNIT;
    }

    @Override public Types visitDoWhile(CompilerParser.DoWhileContext ctx) { //correct
        if (visit(ctx.expr()) != Types.BOOL) {
            throw new TypeException().conditionError();
        }
        if (visit(ctx.block()) != Types.UNIT){
            throw new TypeException().loopBodyError();
        }
        return Types.UNIT;
    }

    @Override public Types visitRepeatUntil(CompilerParser.RepeatUntilContext ctx) { //correct
        if (visit(ctx.block()) != Types.UNIT || visit(ctx.expr()) != Types.BOOL) {
            throw new TypeException().loopBodyError();
        }
        return Types.UNIT;
    }

    @Override public Types visitPrintExp(CompilerParser.PrintExpContext ctx) { //correct
        if (visit(ctx.expr()) != Types.INT || !ctx.expr().getText().equals("newline") || !ctx.expr().getText().equals("space")) {
            throw new TypeException().printError();
        }
        return Types.UNIT;
    }

    @Override public Types visitSpace(CompilerParser.SpaceContext ctx) { //correct
        return Types.UNIT;
    }

    @Override public Types visitNewLine(CompilerParser.NewLineContext ctx) { //correct
        return Types.UNIT;
    }

    @Override public Types visitSkip(CompilerParser.SkipContext ctx) { //correct
        return Types.UNIT;
    }

    @Override public Types visitArgs(CompilerParser.ArgsContext ctx) { //must be added?
        for (int i = 0; i < ctx.expr().size(); ++i) {
            if (visit(ctx.expr(i)) != Types.BOOL || visit(ctx.expr(i)) != Types.INT ){
                throw new TypeException().argumentError();
            }
        }
        return Types.UNIT;
    }
}